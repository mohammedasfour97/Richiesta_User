package com.rkesta.richiesta.app;

import android.content.Context;

import java.util.Locale;

import static com.rkesta.richiesta.util.utility.EN_OR_AR;

public class constant {

    public static final String ImageURl = "http://cp.rkesta.com/prdPic/";

    public static final String KEY_CountryID = "CountryID" ;

    public static final String KEY_CityID = "CityID" ;
    public static final String KEY_CitynameEN = "CitynameEN" ;
    public static final String KEY_CitynameAR = "CitynameAR" ;

    public static final String KEY_currencyEN = "currencyEN" ;
    public static final String KEY_currencyAR = "currencyAR" ;

    public static final String KEY_user_ID = "user_ID";
    public static final String KEY_userAr = "userAr";
    public static final String KEY_userEN = "userEN";
    public static final String KEY_userEmail = "userEmail";
    public static final String KEY_userPhone = "userPhone";
    public static final String KEY_userProPic = "userProPic";
    public static final String KEY_userProPicName = "userProPicName";
    public static final String KEY_userFirstName = "userFirstName";
    public static final String KEY_userLastName = "userLastName";
    public static final String KEY_userFirstNameAR = "userFirstNameAR";
    public static final String KEY_userLastNameAR = "userLastNameAR";

    public static String getcurrency(Context ctx) {
        return EN_OR_AR(ctx,currencyEN,currencyAR);
    }

    public static String currencyEN = "SAR";
    public static String currencyAR = "ر.س";

    /* Locale.US        -> 2,365.12
     * Locale.GERMANY   -> 2.365,12
     */
    public static final Locale PRICE_LOCAL_FORMAT = Locale.US;

    /* true     -> 2.365,12
     * false    -> 2.365
     */
    public static final boolean PRICE_WITH_DECIMAL = true;

    /* true     -> 2.365,12 USD
     * false    -> USD 2.365
     */
    public static final boolean PRICE_CURRENCY_IN_END = true;

    static String GoogleMapKey = "AIzaSyDzO289NRtxK_qxRJ1eaJJanhGqQtyU0AU" ;

}
